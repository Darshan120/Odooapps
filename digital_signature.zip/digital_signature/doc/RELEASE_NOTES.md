## Module <digital_signature>

#### 19.10.2023
#### Version 16.0.1.1.0
#### ADD
- Initial commit for Odoo 16 Digital Signature
