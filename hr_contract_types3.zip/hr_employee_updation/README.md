Open HRMS Employee Info
-----------------------
Supporting Addon for Open HRMS, Added Advanced Fields On Employee Master.

Connect with experts
--------------------

If you have any question/queries/additional works on OpenHRMS or this module, You can drop an email directly to Cybrosys.

Contacts
--------
info - info@cybrosys.com

Website:
https://www.openhrms.com
https://www.cybrosys.com
